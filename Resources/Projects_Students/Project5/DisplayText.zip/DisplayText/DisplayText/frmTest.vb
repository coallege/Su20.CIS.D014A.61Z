﻿Public Class frmTest

  '*********************************************************
  '*** Program: Tests the frmDisplay 
  '             Allows access To printing functions
  '*** Author : Art Linn
  '*** Date   : 12/8/2017
  '*********************************************************
  '    To Use:
  '             Copy files frmDisplay.vb; .resx; .designer.vb
  '               to your Project folder
  '             Add Item -> Existing Files and choose the
  '               frmDisplay.vb
  '             In your project's form you would add a button
  '               that would contain something like:
  '
  '             Dim strAny as string 'You build this string
  '             Dim frmDisp as new frmDisplay
  '             ...
  '             frmDisp.txtDocument.Text = strAny
  '             frmDisp.txtDocument.SelectionStart = 0
  '             frmDisp.ShowDialog()
  '
  Private Sub btnDisplayText_Click(sender As Object, e As EventArgs) Handles btnDisplayText.Click
    'Display text
    Dim strAny As String = txtSampleText.Text
    Dim frmDisp As New frmDisplay

    frmDisp.txtDocument.Text = strAny
    frmDisp.txtDocument.SelectionStart = 0
    frmDisp.ShowDialog()

  End Sub

  Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
    'Closes the window
    Me.Close()

  End Sub

End Class
