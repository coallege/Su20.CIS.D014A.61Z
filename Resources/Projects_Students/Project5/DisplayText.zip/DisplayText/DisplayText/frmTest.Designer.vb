﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTest
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.lblInfo = New System.Windows.Forms.Label()
    Me.lblSampleText = New System.Windows.Forms.Label()
    Me.txtSampleText = New System.Windows.Forms.TextBox()
    Me.btnDisplayText = New System.Windows.Forms.Button()
    Me.btnClose = New System.Windows.Forms.Button()
    Me.SuspendLayout()
    '
    'lblInfo
    '
    Me.lblInfo.AutoSize = True
    Me.lblInfo.Location = New System.Drawing.Point(13, 43)
    Me.lblInfo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.lblInfo.Name = "lblInfo"
    Me.lblInfo.Size = New System.Drawing.Size(410, 40)
    Me.lblInfo.TabIndex = 0
    Me.lblInfo.Text = "Fill in the Sample Textbox and hit the Display Text button." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Examine the code her" &
    "e to use the DisplayText form."
    '
    'lblSampleText
    '
    Me.lblSampleText.AutoSize = True
    Me.lblSampleText.Location = New System.Drawing.Point(13, 114)
    Me.lblSampleText.Name = "lblSampleText"
    Me.lblSampleText.Size = New System.Drawing.Size(144, 20)
    Me.lblSampleText.TabIndex = 1
    Me.lblSampleText.Text = "Enter Sample Text:"
    '
    'txtSampleText
    '
    Me.txtSampleText.Location = New System.Drawing.Point(17, 147)
    Me.txtSampleText.Multiline = True
    Me.txtSampleText.Name = "txtSampleText"
    Me.txtSampleText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
    Me.txtSampleText.Size = New System.Drawing.Size(406, 190)
    Me.txtSampleText.TabIndex = 2
    '
    'btnDisplayText
    '
    Me.btnDisplayText.Location = New System.Drawing.Point(17, 355)
    Me.btnDisplayText.Name = "btnDisplayText"
    Me.btnDisplayText.Size = New System.Drawing.Size(95, 53)
    Me.btnDisplayText.TabIndex = 3
    Me.btnDisplayText.Text = "Display Text"
    Me.btnDisplayText.UseVisualStyleBackColor = True
    '
    'btnClose
    '
    Me.btnClose.Location = New System.Drawing.Point(328, 355)
    Me.btnClose.Name = "btnClose"
    Me.btnClose.Size = New System.Drawing.Size(95, 53)
    Me.btnClose.TabIndex = 4
    Me.btnClose.Text = "Close"
    Me.btnClose.UseVisualStyleBackColor = True
    '
    'frmTest
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(438, 420)
    Me.Controls.Add(Me.btnClose)
    Me.Controls.Add(Me.btnDisplayText)
    Me.Controls.Add(Me.txtSampleText)
    Me.Controls.Add(Me.lblSampleText)
    Me.Controls.Add(Me.lblInfo)
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
    Me.Name = "frmTest"
    Me.Text = "Display Text Tester"
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub

  Friend WithEvents lblInfo As Label
  Friend WithEvents lblSampleText As Label
  Friend WithEvents txtSampleText As TextBox
  Friend WithEvents btnDisplayText As Button
  Friend WithEvents btnClose As Button
End Class
